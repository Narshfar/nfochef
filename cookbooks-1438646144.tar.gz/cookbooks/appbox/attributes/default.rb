default["appbox"]["admin_keys"] = []
default["appbox"]["deploy_keys"] = []
default["appbox"]["apps_dir"] = "/home/apps"

default["appbox"]["admin_user"] = "devops"
default["appbox"]["deploy_user"] = "deploy"
default["appbox"]["apps_user"] = "apps"
