yum-repoforge Cookbook CHANGELOG
================================

v0.5.3 (2015-06-21)
-------------------
- Updating to depend on ~> 3.2

v0.5.2 (2015-06-21)
-------------------
- Support for EL7

v0.5.1 (2015-04-15)
-------------------
- Amazon Linux 2015.03

v0.5.0 (2014-01-07)
-------------------
- Adding centos-7 support

v0.4.0 (2014-09-02)
-------------------
- Add all attribute available to LWRP to allow for tuning

v0.3.0 (2014-06-11)
-------------------
#1 - Support for Amazon Linux 2014.03

v0.2.0 (2014-02-14)
-------------------
- Updating test harness

v0.1.4
------
Adding CHANGELOG.md

v0.1.0
------
initial release
